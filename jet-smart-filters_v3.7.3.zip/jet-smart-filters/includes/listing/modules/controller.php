<?php
namespace Jet_Smart_Filters\Listing\Modules;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main listing/modules class
 */
class Controller {

	public function __construct() {

	}
}
